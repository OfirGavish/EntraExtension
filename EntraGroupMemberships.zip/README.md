# Group Membership Copier Extension

## Overview
This browser extension allows Microsoft Entra (Azure AD) administrators to copy group memberships from one user to another using the Microsoft Graph API. It works in Chrome and Edge.

## Features
- Authenticate as an admin using your own credentials
- Fetch and display all group memberships for a source user
- Select which groups to copy
- Copy selected groups to a target user
- All operations are performed locally and securely using Microsoft Graph API

## Installation
1. Open Chrome or Edge and go to `chrome://extensions` or `edge://extensions`.
2. Enable "Developer mode".
3. Click "Load unpacked" and select the `EntraExtension` folder.
4. Click the extension icon to open the popup.

## Usage
1. Enter the source user's email or UPN and click "Fetch Groups".
2. Select the groups you want to copy.
3. Enter the target user's email or UPN.
4. Click "Copy Selected Groups".
5. Status and errors will be displayed in the popup.

## Permissions
- `identity`: To authenticate the admin user.
- `storage`: To store extension settings (if needed).
- `scripting`: For future enhancements.

## Troubleshooting
- You must be a Microsoft Entra (Azure AD) admin to use this extension.
- If you see permission errors, ensure your account has the required Graph API permissions (`Group.Read.All`, `User.Read.All`, `GroupMember.ReadWrite.All`).
- If you encounter authentication issues, try signing out and back in.

## Security
- The extension only communicates with Microsoft Graph API endpoints.
- No data is sent to any third-party servers.

## License
MIT
